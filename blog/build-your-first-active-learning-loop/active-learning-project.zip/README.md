# What Does Active Learning Look Like in Code?

A small companion project by Bonaventure F. P. Dossou.

## Run

Use Python 3.10 or later. No third-party packages, GPU, API key, or network access are required.

Extract the ZIP, open its folder in VS Code, then run:

```sh
python active_learning.py --seeds 7 23 41 --out results
python -m unittest -v test_project.py
```

On Windows, use `py` instead of `python` if that is your installed launcher.

Open `results/learning-curves.svg` in a browser. CSV files record validation metrics and acquisitions. `results.json` includes the data hash, Python version, configuration, final test confusion matrices (rows=true, columns=predicted; order access, billing, technical), and all runs. A saved model contains the labeled training rows needed to reconstruct the classifier; it is JSON, not an executable pickle.

```sh
python active_learning.py --model results/entropy-7-model.json --predict "Please reset my password."
```

The output folder is reused and matching filenames are overwritten on later runs. Use a new `--out` folder to keep experiments separate. Saved models and acquisition logs contain source text, so handle them like the dataset when substituting private data.

## What this experiment is

The 60 messages are original authored teaching examples, not real support tickets or a benchmark. They are split in advance: 42 training candidates, 9 validation tickets, 9 test tickets. The taxonomy is known in advance. A pseudorandom seed chooses six initial labeled examples without consulting their labels; a class can be missing from this initial sample.

Each strategy acquires three labels per round, for six rounds. Both start with the same seed and evaluation sets. Entropy sampling scores the remaining pool and chooses the three largest scores; random selection is uniform without replacement. Uniform class priors, add-one smoothing, labeled-only vocabulary, and a simple `[a-z]+` tokenizer define the multinomial Naive Bayes baseline. This is predictive entropy, not BALD. Model probabilities are not calibrated confidence estimates.

The Python and browser code use the same 32-bit generator and round scores to 12 decimals only for tie ordering. Initial label IDs, acquired IDs, and metrics should match. Tiny floating-point differences are possible across engines. The browser lets you finish early; Python uses a fixed round budget (`--rounds 0` tests only the initial model).

Validation is evaluated after every fit, but never used by the selection policy or fixed stopping plan. Final test evaluation occurs after acquisition ends. Do not select a configuration based on repeated test inspection and then report that same set as an independent final estimate.

## Your own labeled replay

Prepare a UTF-8 CSV with `id,text,label,split`. Quote texts containing commas. Use labels `access`, `billing`, `technical` and splits `train`, `validation`, `test`. Each split must include all three classes for this tutorial. Adapt `CLASSES` and tests for a different taxonomy.

```sh
python active_learning.py --csv my_tickets.csv --initial 30 --batch 10 --rounds 10 --seeds 7 23 41 --out my-results
```

There must be more training candidates than initial labels. Pool exhaustion automatically stops acquisition; a last batch may be smaller. Exact normalized duplicates and empty texts are rejected. Near-duplicates and grouping by conversation, customer, or time must be addressed before splitting. The English tokenizer is intentionally limited; replace it before multilingual use.

This script is an offline replay: existing labels simulate a human oracle. It does not provide a live annotation service. For a genuinely unlabeled pool, export the selected IDs and texts without labels, obtain reviewed human annotations, validate ID coverage and allowed categories, and only then update. Keep unresolved items pending. The acquisition CSV this replay exports includes revealed reference labels for auditing, not blank annotation requests.

## Costs and outputs

At the default budget, each strategy uses 24 training labels. Entropy acquisition scores 171 pool-document instances, random acquisition zero. Full refits process 105 training-document instances per strategy. Each strategy makes 63 validation and 9 final test predictions. These counts are work proxies, not FLOPs or GPU timings. They do not include the optional prediction playground.

`fit_seconds` is local CPU wall time for fitting. `acquisition_seconds` is selection time for the next batch from that row's model, excluding oracle annotation. Cumulative score-work in a row describes work already used to reach that round, so the last row contains the six-round total. Validation, final evaluation, file I/O, and human annotation time are excluded from those timing columns.

Evaluation labels also have a cost. At a hypothetical two minutes per label, 24 training plus 18 evaluation labels take 84 minutes for one strategy. Strategies share some labels, so comparison cost is not simply twice that number.

## Reading

- [Interactive essay](https://bonaventuredossou.github.io/blog/build-your-first-active-learning-loop/index.html)
- [Settles, Active Learning Literature Survey](https://burrsettles.com/pub/settles.activelearning.pdf)
- [Manning, Raghavan, and Schütze, Naive Bayes text classification](https://nlp.stanford.edu/IR-book/html/htmledition/naive-bayes-text-classification-1.html)
- [Scikit-learn: Naive Bayes](https://scikit-learn.org/stable/modules/naive_bayes.html)
- [Scikit-learn: avoiding data leakage](https://scikit-learn.org/stable/common_pitfalls.html)

This project illustrates the mechanics of an experiment. It makes no claim that entropy sampling consistently beats random acquisition.
